// =================== LABIRINTO ===================
const mazeData = [
    [0,0,1,0,0,0,1,0,0,0,0,1,0,0,0],
    [0,1,1,1,1,0,1,0,1,1,0,1,0,1,0],
    [0,0,0,0,1,0,0,0,1,0,0,0,0,1,0],
    [1,1,1,0,1,1,1,0,1,0,1,1,0,1,0],
    [0,0,0,0,0,0,1,0,0,0,1,0,0,0,0],
    [0,1,1,1,1,0,1,1,1,0,1,1,1,1,0],
    [0,0,0,0,1,0,0,0,0,0,0,0,0,0,0],
    [0,1,1,0,1,1,1,1,1,1,1,1,1,1,0],
    [0,0,0,0,0,0,0,0,1,0,0,0,0,1,0],
    [0,1,1,1,1,1,1,0,0,0,1,1,0,0,0]
];

const start = [0,0], goal = [9,14];
const maze = document.getElementById("maze");
const bestPathMsg = document.getElementById("best-path-msg");
const sleep = ms => new Promise(r => setTimeout(r, ms));

// =================== PER SALVARE I RISULTATI ===================
const results = {}; // es: { BFS: {path: [...], length: 10}, DFS: {...}, A*: {...} }

// =================== DISEGNA LABIRINTO ===================
function drawMaze() {
    maze.innerHTML = "";
    mazeData.forEach((r,i) => r.forEach((c,j) => {
        const d = document.createElement("div");
        d.className = "cell";
        if(c) d.classList.add("wall");
        if(i===start[0] && j===start[1]) d.classList.add("start");
        if(i===goal[0] && j===goal[1]) d.classList.add("goal");
        d.id = `c-${i}-${j}`;
        maze.appendChild(d);
    }));
}
drawMaze();

// =================== FUNZIONI AUSILIARIE ===================
function neighbors([x,y]){
    return [[x+1,y],[x-1,y],[x,y+1],[x,y-1]]
        .filter(n=>n[0]>=0&&n[1]>=0&&n[0]<mazeData.length&&n[1]<mazeData[0].length&&mazeData[n[0]][n[1]]===0);
}

function heuristic(a,b){
    return Math.abs(a[0]-b[0]) + Math.abs(a[1]-b[1]);
}

// =================== ALGORITMI ===================
function bfsSolve(){
    let q=[[start,[start]]], visited=[], set=new Set([start.join(",")]);
    while(q.length){
        let [n,p] = q.shift(); 
        visited.push(n);
        if(n.join(",") === goal.join(",")) return {path:p, visited:visited};
        neighbors(n).forEach(nb=>{
            let key = nb.join(",");
            if(!set.has(key)) {
                set.add(key);
                q.push([nb,[...p,nb]]);
            }
        });
    }
    return {path:[], visited:visited};
}

function dfsSolve(){
    let stack=[[start,[start]]], visited=[], set=new Set([start.join(",")]);
    while(stack.length){
        let [n,p] = stack.pop();
        visited.push(n);
        if(n.join(",") === goal.join(",")) return {path:p, visited:visited};
        neighbors(n).forEach(nb=>{
            let key = nb.join(",");
            if(!set.has(key)) { set.add(key); stack.push([nb,[...p, nb]]); }
        });
    }
    return {path:[], visited:visited};
}

function aStarSolve(){
    let open=[[heuristic(start,goal),0,start,[start]]], visited=[], set=new Set();
    while(open.length){
        open.sort((a,b)=>a[0]-b[0]);
        let [f,g,n,p] = open.shift();
        let key = n.join(",");
        if(set.has(key)) continue;
        set.add(key); visited.push(n);
        if(key === goal.join(",")) return {path:p, visited:visited};
        neighbors(n).forEach(nb=>{
            open.push([g+1+heuristic(nb,goal), g+1, nb, [...p, nb]]);
        });
    }
    return {path:[], visited:visited};
}

// =================== ANIMAZIONE ===================
async function animate(path, visited, visitedClass, pathClass){
    for(let [x,y] of visited){
        const el = document.getElementById(`c-${x}-${y}`);
        if(el && !el.classList.contains("start") && !el.classList.contains("goal")){
            el.classList.add(visitedClass);
            el.style.transition = "all 0.3s ease";
            el.style.transform = "scale(1.1)";
            await sleep(20 + Math.random()*15);
            el.style.transform = "scale(1)";
        }
    }

    for(let [x,y] of path){
        const el = document.getElementById(`c-${x}-${y}`);
        if(el && !el.classList.contains("start") && !el.classList.contains("goal")){
            el.classList.add(pathClass);
            el.style.transition = "all 0.3s ease";
            el.style.boxShadow = "0 0 20px #22c55e, 0 0 40px #22c55e88 inset";
            let pulse = 0;
            const pulseInterval = setInterval(() => {
                pulse = pulse === 0 ? 1 : 0;
                el.style.transform = pulse ? "scale(1.2)" : "scale(1.05)";
            }, 250);
            await sleep(50);
            clearInterval(pulseInterval);
            el.style.transform = "scale(1)";
        }
    }
}

// =================== PERCORSO MIGLIORE ===================
function showBestPath(algorithm, length){
    bestPathMsg.innerText = `🏆 Percorso migliore: ${algorithm}, lunghezza ${length}`;
    bestPathMsg.classList.remove("hidden");
    bestPathMsg.classList.add("show");
}

// =================== AGGIORNA / CREA VOCE NELLO STORICO ===================
function updateHistory(alg, visitedLen, pathLen){
    // Sanifica id (sostituisce caratteri problematici come '*')
    const safe = alg.replace(/\*/g, "star");
    const container = document.getElementById("history");
    let el = document.getElementById(`history-${safe}`);
    if(!el){
        el = document.createElement("p");
        el.id = `history-${safe}`;
        container.appendChild(el);
    }
    el.innerHTML = `${alg}: ${visitedLen} nodi esplorati, percorso ${pathLen}`;
}

// =================== CONFRONTO TRA TUTTI I PERCORSI ===================
function updateBestPath() {
    let bestAlg = null;
    let bestLen = Infinity;
    for(let alg in results){
        if(results[alg].length > 0 && results[alg].length < bestLen){
            bestLen = results[alg].length;
            bestAlg = alg;
        }
    }
    if(bestAlg) showBestPath(bestAlg, bestLen);
}

// =================== BOTTONI ===================
async function runBFS(){
    drawMaze();
    const res = bfsSolve();
    await animate(res.path, res.visited, "visited-bfs", "path-bfs");

    // aggiorna storico (una sola voce per algoritmo)
    updateHistory("BFS", res.visited.length, res.path.length);

    // salva risultato e aggiorna il migliore
    results["BFS"] = {path: res.path, length: res.path.length};
    updateBestPath();
}

async function runDFS(){
    drawMaze();
    const res = dfsSolve();
    await animate(res.path, res.visited, "visited-dfs", "path-dfs");

    updateHistory("DFS", res.visited.length, res.path.length);

    results["DFS"] = {path: res.path, length: res.path.length};
    updateBestPath();
}

async function runAStar(){
    drawMaze();
    const res = aStarSolve();
    await animate(res.path, res.visited, "visited-astar", "path-astar");

    updateHistory("A*", res.visited.length, res.path.length);

    results["A*"] = {path: res.path, length: res.path.length};
    updateBestPath();
}
