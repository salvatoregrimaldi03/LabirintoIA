# LabirintoIA

<p align="center"><img src='https://i.postimg.cc/xjbVPhTP/Logo-Labirinto-IA2.png' alt="LabirintoIA Logo" height="400"></p>


## Authors 🧑‍💻​🧑‍💻​

- **Salvatore Grimaldi** - [SalvatoreGrimaldi](https://github.com/salvatoregrimaldi03)
- **Ciro Esposito** - [CiroEsposito](https://github.com/ciroesposito04)
- **Lorenzo Di Riso** - [LorenzoDiRiso](https://github.com/ldiriso4)
